package model;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.regex.Pattern;

public class PhishModelCounter {

	static final String IPV4_REGEX = "(([0-1]?[0-9]{1,2}\\.)|(2[0-4][0-9]\\.)|(25[0-5]\\.)){3}(([0-1]?[0-9]{1,2})|(2[0-4][0-9])|(25[0-5]))";
	static Pattern IPV4_PATTERN = Pattern.compile(IPV4_REGEX);

	static int phish = 0;
	static String[] keywords = { "Verify", "Account", "Login", "Update",
			"Confirm", "User", "Customer", "Client", "Suspend", "Restrict",
			"Hold", "Username", "Password", "SSN", "Social", "Security" };
	static String[] blacklist = { "http://ianfette.org", "http://gumblar.cn",
			"http://rahngmbh.ch", "http://hotelaxl.ch/",
			"http://genelake.com ", "http://www.nbci.com",
			"http://videopodcasts.tv", "http://soundofacapulco.com/",
			"http://how-to-win-a-lottery.net/", "http://geospace-online.com/",
			" http://videodownloader.net/", "http://friesenpferde.com/",
			"http://massiveonlinegamer.com/" };

	public boolean isPhish(List<String> content, List<String> links) throws MalformedURLException {

		for (int i = 0; i < links.size(); i++) {
			for (int j = 0; j < blacklist.length; j++) {
				URL urlOne = new URL(links.get(i));
				URL urlTwo = new URL(blacklist[j]);

				if( urlOne.equals(urlTwo) )
				{
					return true;
				}
				
			}
		}
		for (int i = 0; i < keywords.length; i++) {
			for (int j = 0; j < content.size(); j++) {
				if (content.get(i).contains(keywords[i])) {
					phish++;
				}
			}
		}
		
		//fix this 

//		String findStr = "http";
//		int lastIndex = 0;
//		int count = 0;
//
//		for (int i = 0; i < links.size(); i++) {
//			while (lastIndex != -1) {
//
//				lastIndex = links.get(i).indexOf(findStr, lastIndex);
//
//				if (lastIndex != -1) {
//					count++;
//					lastIndex += findStr.length();
//				}
//			}
//		}
//		
//		int counter = 0;
//		for (int i = 0; i < links.size(); i++) {
//			if (!isValidIPV4(links.get(i), IPV4_PATTERN )|| links.get(i).length() > 75 || links.get(i).contains("-")
//					|| links.get(i).contains("_") || links.get(i).contains("@")
//					|| links.get(i).contains(",") || links.get(i).contains(";")) {
//				return true;
//			}
//			if (links.get(i).charAt(i) == '.') {
//				counter++;
//
//			}
//		}
//
//		if (counter >= 5) {
//			return true;
//		}
//		if (count > 1) {
//			return true;
//		}
		if (phish > 10) {
			return true;
		}

		return false;
	}
	
//	private boolean isValidIPV4(final String s,Pattern pattern) {
//		return pattern.matcher(s).matches();
//		
//	}
}
