package model;

import java.util.ArrayList;
import java.util.List;

public class Mail {
	private int Id;
	private String Subject;
	private String Url;
	private String Sender;
	// private String Content;
	// private String Links;
	private boolean Status;

	private List<String> Content = new ArrayList<String>();
	private List<String> Links = new ArrayList<String>();

	public Mail() {
	}

	public Mail(int Id, String Subject, String Url, String Sender) {
		this.Id = Id;
		this.Subject = Subject;
		this.Url = Url;
		this.Sender = Sender;

	}

	public void setContent(List<String> list) {
		this.Content = list;

	}

	public void setLinks(List<String> list) {

		this.Links = list;

	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getSubject() {
		return Subject;
	}

	public void setSubject(String subject) {
		Subject = subject;
	}

	public String getUrl() {
		return Url;
	}

	public void setUrl(String urls) {
		Url = urls;
	}

	public String getSender() {
		return Sender;
	}

	public void setSender(String sender) {
		Sender = sender;
	}

	public List<String> getContent() {
		return Content;
	}

	public List<String> getLinks() {
		return Links;
	}

	public String toString() {

		return Id + " " + Subject + " " + Url + " " + Sender;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

}
