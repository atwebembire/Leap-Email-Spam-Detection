package controller;

import java.util.*;
import java.io.*;

import view.Display;
import model.HtmlParser;
import model.LinkParser;
import model.Mail;
import model.PhishModelCounter;

public class Controller {

	public static HtmlParser parser = new HtmlParser();
	public static Mail mail;
	public static ArrayList<Mail> mailList = new ArrayList<Mail>();
	public static HtmlParser html = new HtmlParser();
	public static LinkParser links = new LinkParser();
	private static PhishModelCounter phish = new PhishModelCounter();

	public static void main(String[] args) throws Exception {
		
		int Id = 0;
		String Subject = null;
		String Url = null;
		String Sender = null;
		// String Content = null;
		// String Links = null;
		String delimeter = ";";
		Scanner inputStream = null;
		StringTokenizer tokens;
		try {
			inputStream = new Scanner(new FileInputStream("mails.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found!");
			System.exit(0);
		}
		String mail = null;
		// int count = 0;
		while (inputStream.hasNextLine()) {

			mail = inputStream.nextLine();

			tokens = new StringTokenizer(mail, delimeter);

			Id = Integer.parseInt(tokens.nextToken());
			Subject = tokens.nextToken();
			Url = tokens.nextToken();
			Sender = tokens.nextToken();

			// count++;
			// System.out.println(count);
			mailList.add(new Mail(Id, Subject, Url, Sender));
		}
		inputStream.close();
		for (int i = 0; i < mailList.size(); i++) {

			// call HtmlParser with the url HtmlParser returns content links

			// set content and links...move onto next object and do the same
			// thing

			mailList.get(i).setContent(
					html.readContent(mailList.get(i).getUrl()));
			mailList.get(i).setLinks(
					links.readContent(mailList.get(i).getUrl()));

		}
		// test
		Mail status = new Mail();
		
		
		for (int i = 0; i < mailList.size(); i++) {
			
			mailList.get(i).setStatus(phish.isPhish(mailList.get(i).getContent(),mailList.get(i).getLinks()));;
		}
		
			//status.setStatus(isPhish);
//		for (int i = 0; i < mailList.size(); i++) {
//			List<String> temp = mailList.get(i).getLinks();
//			List<String> temp2 = mailList.get(i).getContent();}
//			for (String link : temp) {
//				System.out.println(link);
//			}
//			 for (String content : temp2)
//			 {
//			 System.out.println(content);
//			 }
		
		
		Display frame = new Display();
		frame.setVisible(true);
		// TO DO NEXT
		
		// USING MODEL CLASS compare extracted info against blacklist keywords and sites
		// GUI to display emails
		// final report

	}

	public ArrayList<Mail> getMails() {
		
		return mailList;
	}

}
