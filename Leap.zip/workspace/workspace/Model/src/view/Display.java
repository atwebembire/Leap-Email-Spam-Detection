package view;

import javax.swing.*;

import controller.Controller;
import model.Mail;
import model.PhishModelCounter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

@SuppressWarnings("serial")
public class Display extends JFrame implements ActionListener{

	private static final int FRAME_WIDTH = 700;
	private static final int FRAME_HEIGHT = 550;
	private static final int FRAME_X_ORIGIN = 150;
	private static final int FRAME_Y_ORIGIN = 50;
	
	private static ArrayList<Mail> mList = new ArrayList<Mail>();
	JButton viewButton;
	private JList mailList;
	private StringTokenizer tokens;
	private static String[] mailIds;
	
	private static PhishModelCounter phish = new PhishModelCounter();
	
	//Display mailPanel;
	
	static JTextPane tp = new JTextPane();
	static JScrollPane js = new JScrollPane(tp);
	//static Display temp = new Display();
    
	public static Controller fetch = new Controller();
//	public static void main(String[] args) {
//		Display frame = new Display();
//		
//		
//	}

	public Display() {
		
		Container contentPane;
		
		JPanel controlPanel;
		JPanel listPanel;
		
		mList = fetch.getMails();
		mailIds = new String[mList.size()];
		
		//System.out.println("Here");
		for(int i = 0; i< mList.size(); i++)
		{
			
			mailIds[i] = mList.get(i).getId() + "|" +" " + mList.get(i).getSubject();
			//System.out.println("Here");
		}
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		setTitle("LEAP");
		setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);

		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout(10, 0));

		//mailPanel = new Display();
		tp.setEditable(false);
		tp.setBorder(BorderFactory.createLoweredBevelBorder());
		js.getViewport().add(tp);
		controlPanel = new JPanel();
		controlPanel.setLayout(new BorderLayout());
		
		contentPane.add(js, BorderLayout.CENTER);
		contentPane.add(controlPanel, BorderLayout.WEST);

		listPanel = new JPanel();
		listPanel.setBorder(BorderFactory.createTitledBorder("Mail ID" + " " +"|"+" "+"Subject"));
		listPanel.setLayout(new GridLayout(0, 1));
		
		// add list items to panel

		mailList = new JList(mailIds);
		listPanel.add(mailList);
		mailList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		controlPanel.add(listPanel, BorderLayout.NORTH);
		viewButton = new JButton("View Mail");
		viewButton.addActionListener(this);
		controlPanel.add(viewButton, BorderLayout.SOUTH);
		//listPanel.add(new JButton("View Mail"), BorderLayout.SOUTH);

		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	public void actionPerformed(ActionEvent event)
	{
		String uri = null;
		int tempId;
		Object Id;
		Id = mailList.getSelectedValue();
		tokens = new StringTokenizer((String) Id, "|");
		tempId = Integer.parseInt(tokens.nextToken());
		
//		List<String> content = null;
//		List<String> links = null;
		
		uri = mList.get(tempId).getUrl();
				
		try {
			URL url = getClass().getResource(uri);
			tp.setPage(url);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (mList.get(tempId).isStatus()) {
			JOptionPane.showMessageDialog(null, "PHISHING ATTACK DETECTED");
			//System.out.println("PHISHING ATTACK DETECTED");
		}
		if (!mList.get(tempId).isStatus()) {
			JOptionPane.showMessageDialog(null, "MAIL IS CLEAN");
			//System.out.println("MAIL IS CLEAN");
		}
		//boolean isPhish = phish.Classify(content, links);//mList = fetch.getMails();
		
		
		//System.out.println(tempId);
	}
	public static int getFrameWidth() {
		return FRAME_WIDTH;
	}

	public static int getFrameHeight() {
		return FRAME_HEIGHT;
	}

	public static int getFrameXOrigin() {
		return FRAME_X_ORIGIN;
	}

	public static int getFrameYOrigin() {
		return FRAME_Y_ORIGIN;
	}

	
}
